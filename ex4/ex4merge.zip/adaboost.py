"""
===================================================
     Introduction to Machine Learning (67577)
===================================================

Skeleton for the AdaBoost classifier.

"""
import numpy as np
from ex4_tools import *


def train_and_test(train_samples_num, T, test_samples_num, noise_factor):
    # q13 -----------------------------------
    x_train, y_train = generate_data(train_samples_num, noise_factor)
    x_test, y_test = generate_data(test_samples_num, noise_factor)

    adabost = AdaBoost(DecisionStump, T)
    weight_d = adabost.train(x_train, y_train)
    training_error, test_error = [], []

    for t in range(1, T+1):
        training_error.append(adabost.error(x_train, y_train, t))

        test_error.append(adabost.error(x_test, y_test, t))
        # print("train error " , training_error)
        #
        # print("test error " , test_error)


    domain_x = np.arange(0, T)
    plt.plot(domain_x, training_error, color="orange")
    plt.plot(domain_x, test_error, color="blue")
    # plt.plot(m, svm_mean_acc, color="green")
    plt.title("train and test error difference with noise ratio = " + str(noise_factor))
    plt.legend(["training error", "test error"], bbox_to_anchor=(1.05, 1), loc='upper left',
               borderaxespad=0.)
    plt.tight_layout()
    plt.show()
    # print("returnfro tst and test")

    # q14 ------------------------------------------
    t_set = [5, 10, 50, 100, 200, 500]
    for plot_index, t in enumerate(t_set):
        plt.subplot(2, 3, plot_index + 1)
        decision_boundaries(adabost, x_test, y_test, t)
    plt.show()

    # q15 ------------------------------------------
    arg_min_index = np.argmin(test_error)
    print("test error list: ", test_error)
    print("min index: ", arg_min_index, "arg min value = ", test_error[arg_min_index])
    decision_boundaries(adabost, x_train, y_train, arg_min_index + 1)
    plt.show()

    # q16 ------------------------------------------
    decision_boundaries(adabost, x_train, y_train, T, weight_d)
    plt.show()
    print("16 start")
    # print(weight_d)
    # print("---")
    weight_d = weight_d / np.max(weight_d) * 10
    # print(weight_d)
    decision_boundaries(adabost, x_train, y_train, T, weight_d)
    plt.show()
    print("16 end")
    return




class AdaBoost(object):

    def __init__(self, WL, T):
        """
        Parameters
        ----------
        WL : the class of the base weak learner
        T : the number of base learners to learn
        """
        self.WL = WL
        self.T = T
        self.h = [None]*T     # list of base learners
        self.w = np.zeros(T)  # weights

    def train(self, X, y):
        """
        Parameters
        ----------
        X : samples, shape=(num_samples, num_features)
        y : labels, shape=(num_samples)
        Train this classifier over the sample (X,y)
        After finish the training return the weights of the samples in the last iteration.
        """
        # TODO complete this function
        print(X.shape[0])
        weighted_distirbut = np.ones(X.shape[0]) / X.shape[0]  # D1 = (1/m,..,1/m)
        weak_learner = self.WL
        # print("iteration 0: wd = ", weighted_distirbut)
        for t in range(0, self.T):
            # print("------------")
            ht = weak_learner(weighted_distirbut, X, y)
            ht_predict = ht.predict(X)
            epsilon_t = np.sum(weighted_distirbut[(y != ht_predict)])
            # print("epslit t =" ,epsilon_t)
            wt = (0.5) * np.log((1/epsilon_t) - 1)
            numerator = weighted_distirbut * np.exp(-wt * y * ht_predict)
            # next_distirbut = (weighted_distirbut * np.exp(-wt * y * ht_predict)) / np.sum(weighted_distirbut * np.exp(-wt * y * ht_predict))
            # weighted_distirbut = next_distirbut
            weighted_distirbut = numerator / numerator.sum()
            self.h[t] = ht
            self.w[t] = wt
        return weighted_distirbut

    def predict(self, X, max_t):
        """
        Parameters
        ----------
        X : samples, shape=(num_samples, num_features)
        :param max_t: integer < self.T: the number of classifiers to use for the classification
        :return: y_hat : a prediction vector for X. shape=(num_samples)
        Predict only with max_t weak learners,
        """
        # TODO complete this function
        y_predict = np.zeros((X.shape[0]))
        for t in range(0, max_t):
            y_predict += (self.w[t] * self.h[t].predict(X))
        return np.sign(y_predict)

    def error(self, X, y, max_t):
        """
        Parameters
        ----------
        X : samples, shape=(num_samples, num_features)
        y : labels, shape=(num_samples)
        :param max_t: integer < self.T: the number of classifiers to use for the classification
        :return: error : the ratio of the wrong predictions when predict only with max_t weak learners (float)
        """
        # TODO complete this function
        y_predict = self.predict(X, max_t)
        return (y_predict[(y_predict != y)].shape[0]) / X.shape[0]


if __name__ == '__main__':
    # train_and_test(5000, 500, 200, 0)
    # train_and_test(5000, 500, 200, 0.01)
    train_and_test(5000, 500, 200, 0.4)